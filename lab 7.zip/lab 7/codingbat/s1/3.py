def make_tags(tag, word):
  return '<{}>{}</{}>'.format(tag, word, tag)
