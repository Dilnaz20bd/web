def array_front9(nums):
  return nums[:4].count(9) > 0

