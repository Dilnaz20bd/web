def front_times(str, n):
  return str[:3]*n
