def double_char(str):
  return ''.join(x + x for x in str)
