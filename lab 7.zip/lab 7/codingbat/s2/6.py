def xyz_there(str):
  return str.count('.xyz') < str.count('xyz')
