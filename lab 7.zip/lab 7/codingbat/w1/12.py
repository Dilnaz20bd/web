def front3(str):
  front = str[:3]
  return front * 3
