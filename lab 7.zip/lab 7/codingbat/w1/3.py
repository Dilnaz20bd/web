def sum_double(a, b):
  sum = a + b
  return sum + (a == b) * sum