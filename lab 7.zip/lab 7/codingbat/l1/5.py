def sum3(nums):
  return sum(nums)
