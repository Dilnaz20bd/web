def has23(nums):
  return nums.count(2) + nums.count(3) > 0
