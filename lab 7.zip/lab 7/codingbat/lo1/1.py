def cigar_party(cigars, is_weekend):
  return cigars >= 40 and (is_weekend or cigars <= 60)
