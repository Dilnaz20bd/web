def in1to10(n, outside_mode):
  return n in (1, 10) or ((1 < n < 10) != outside_mode)
