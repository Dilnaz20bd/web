def squirrel_play(temp, is_summer):
  return 60 <= temp <= (90 + is_summer * 10)
