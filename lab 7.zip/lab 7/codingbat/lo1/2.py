def date_fashion(you, date):
  return 0 if you < 3 or date < 3 else 2 if you > 7 or date > 7 else 1
