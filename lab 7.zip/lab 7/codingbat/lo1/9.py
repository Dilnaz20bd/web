def near_ten(num):
  return 8 <= num % 10 or num % 10 <= 2
