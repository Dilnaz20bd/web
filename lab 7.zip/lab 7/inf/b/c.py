t = int(input())
s = int(input())
print('YES' if (t == 1 and s == 1) or (t != 1 and s != 1) else 'NO')