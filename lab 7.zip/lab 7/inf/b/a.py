n = int(input())
k = int(input())
print(max(n, k))