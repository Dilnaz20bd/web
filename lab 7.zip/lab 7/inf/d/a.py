input()
print(*input().split()[::2])