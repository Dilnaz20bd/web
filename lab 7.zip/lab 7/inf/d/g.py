input()
a = input().split()[::-1]
print(*a)