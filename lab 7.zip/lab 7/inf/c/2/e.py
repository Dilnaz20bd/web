n = int(input())
k = 0
res = 1
while res < n:
    k += 1
    res *= 2
print(k)