n = int(input())
for i in range(1, n + 1):
    if i * i > n: break
    print(i * i)