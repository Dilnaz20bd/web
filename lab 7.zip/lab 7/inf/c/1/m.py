n = int(input())
print(sum(int(input()) == 0 for _ in range(n)))