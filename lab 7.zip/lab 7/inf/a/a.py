a = int(input())
b = int(input())

from math import sqrt
print(sqrt(a**2 + b**2))
