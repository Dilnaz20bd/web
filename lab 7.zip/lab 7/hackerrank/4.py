# https://www.hackerrank.com/challenges/python-division/problem

a = int(input())
b = int(input())

print(a // b, a / b, sep='\n')
