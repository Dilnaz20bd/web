# https://www.hackerrank.com/challenges/python-loops/problem

print(*(i**2 for i in range(int(input()))), sep='\n')
