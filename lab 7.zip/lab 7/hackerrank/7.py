# https://www.hackerrank.com/challenges/python-print/problem

print(''.join(str(i) for i in range(1, int(input()) + 1)))
